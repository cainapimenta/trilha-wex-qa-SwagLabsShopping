Feature: Como o usuário deseja acessar a pagina inicial, sem pular diretamente para tela de login
    @TestCaseKey=SWAG-T1
    Scenario: Como o usuário deseja acessar a pagina inicial, sem pular diretamente para tela de login
        
        Given que o Cliente acesse a loja virtual
        
        And não esteja autenticado no sistema
        
        When acessar a página inicial
        
        Then deverá visualizar os produtos disponíveis para venda
        
        And poderá navegar pela página sem realizar login