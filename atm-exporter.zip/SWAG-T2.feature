Feature: Como o usuário deseja preencher o formulário para criação de conta em loja virtual?
    @TestCaseKey=SWAG-T2
    Scenario: Como o usuário deseja preencher o formulário para criação de conta em loja virtual?
        
        Given que o Cliente esteja na tela de login
        
        And possua cadastro no sistema
        
        When informar um usuário válido
        
        And informar uma senha válida
        
        And clicar em "Entrar"
        
        Then deverá ser autenticado no sistema
        
        And deverá ter acesso às funcionalidades disponíveis para usuários logados